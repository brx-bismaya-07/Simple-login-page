<?php
$con=mysqli_connect("localhost","root","","user_login");
if(isset($_POST['su']))
{
 $name=$_POST['na'];
 $pass=$_POST['pwd'];
$sql="insert into info(Name,Password) values('$name','$pass')";

$query=mysqli_query($con,$sql);
}
?>